export interface rewardsI {
   id: string;
   antimatter:number;
}
