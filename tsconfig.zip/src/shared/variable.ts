export const chain: string[] = ['0x4', 'rinkeby', 'polygon'];
export const address_3d_bull = '0x07a8ba3F4fd4Db7f3381C07ee5a309c1aacE9C59';
export const address_2d_bull = '';
export const address_staking = '';

export function meta_bull2D (id:string) {
   return `https://opensea.mypinata.cloud/ipfs/bafybeibhfvxvbfoh7ikdfkw7nyeldgic2nprjvnoz6ym5kmablbohz7pia/${id}.json`
}

