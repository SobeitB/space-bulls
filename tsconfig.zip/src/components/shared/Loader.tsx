export const Loader = () => {
   return(
      <>
         <h2 style={{
            "fontSize":"21px",
            "color":"#FFFFFF"
         }}>Loading. . .</h2>
         <div className="lds-ring"><div></div><div></div><div></div><div></div></div>
      </>
   );
};