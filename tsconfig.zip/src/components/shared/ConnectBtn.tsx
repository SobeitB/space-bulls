import {ConnectButton} from 'web3uikit'

export const ConnectWallet = () => {
   
   return(
      <div className='ConnectButton'>
         <ConnectButton />
      </div>
   );
}